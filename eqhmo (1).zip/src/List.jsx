import React from "react";

function List() {
  return (
    <ul className="List">
      <li>Java script</li>
      <li>React JS</li>
    </ul>
  );
}

export default List;
