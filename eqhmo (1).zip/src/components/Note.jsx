import React from "react";
function Note() {
  return (
   <div className = "note">
     <h1>Web Dev with JavaScript and React JS</h1>
     <p>This was an amazing boot camp taken by shuraya sinha sir, they coverd every thing from scratch including java script and React JS.</p>
       <h1>Comments </h1>
     <li> I personaly learned many things from this boot camp thank you for making such a wonderfull session sir</li>
  </div>
  );
}
export default Note;