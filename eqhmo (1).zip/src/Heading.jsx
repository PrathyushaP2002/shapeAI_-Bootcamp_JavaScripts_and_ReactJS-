import React from "react";

function Heading() {
  return<h1 className = "heading"> shape AI</h1>;
}

  export default Heading;
  